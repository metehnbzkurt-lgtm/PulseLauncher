package com.pulse.launcher.core.model
typealias FolderInfoModel = FolderInfo
