package com.pulse.launcher.di

import android.content.Context
import com.pulse.launcher.core.drawer.AppDrawerController
import com.pulse.launcher.core.drawer.DrawerTabManager
import com.pulse.launcher.core.folder.FolderController
import com.pulse.launcher.data.database.dao.DrawerGroupDao
import com.pulse.launcher.features.badges.BadgeManager
import com.pulse.launcher.features.search.SearchController
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideAppDrawerController() = AppDrawerController()

    @Provides
    @Singleton
    fun provideDrawerTabManager(dao: DrawerGroupDao) = DrawerTabManager(dao)

    @Provides
    @Singleton
    fun provideSearchController() = SearchController()

    @Provides
    @Singleton
    fun provideBadgeManager() = BadgeManager()

    @Provides
    @Singleton
    fun provideFolderController() = FolderController()
}
