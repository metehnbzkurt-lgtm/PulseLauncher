package com.pulse.launcher.data.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "drawer_groups")
data class DrawerGroupEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val groupType: String, // TAB, FOLDER_GROUP, HIDDEN
    val tabOrder: Int = -1,
    val hideApps: Boolean = false,
    val icon: ByteArray? = null,
    val tabColor: Int = 0,
    val flags: Int = 0,
    val modified: Long = System.currentTimeMillis()
)
