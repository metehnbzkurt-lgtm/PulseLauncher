package com.pulse.launcher.core

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PulseApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Global init: Coil, Room pre-warm, IconCache, etc.
    }
}
