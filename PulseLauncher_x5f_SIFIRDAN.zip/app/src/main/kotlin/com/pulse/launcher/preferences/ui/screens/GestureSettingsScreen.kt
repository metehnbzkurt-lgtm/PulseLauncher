package com.pulse.launcher.preferences.ui.screens

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.pulse.launcher.core.gesture.GestureAction
import com.pulse.launcher.core.gesture.GestureType
import com.pulse.launcher.preferences.ui.FancyPrefDropdown

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GestureSettingsScreen(onBack: () -> Unit) {
    val gestures = listOf(
        GestureType.SWIPE_UP to "Swipe Up",
        GestureType.SWIPE_DOWN to "Swipe Down",
        GestureType.DOUBLE_TAP to "Double Tap",
        GestureType.PINCH_IN to "Pinch In",
        GestureType.PINCH_OUT to "Pinch Out",
        GestureType.TWO_FINGER_SWIPE to "Two Finger Swipe",
        GestureType.LONG_PRESS to "Long Press",
        GestureType.HOME_PRESS to "Home Button"
    )
    var selections by remember { mutableStateOf(gestures.associate { it.first to GestureAction.NONE }) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Gestures") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }) }
    ) { padding ->
        LazyColumn(contentPadding = padding) {
            gestures.forEach { (type, label) ->
                item {
                    FancyPrefDropdown(
                        title = label,
                        options = GestureAction.entries,
                        selected = selections[type] ?: GestureAction.NONE,
                        label = { it.displayName },
                        onSelected = { selections = selections.toMutableMap().apply { put(type, it) } }
                    )
                }
            }
        }
    }
}
