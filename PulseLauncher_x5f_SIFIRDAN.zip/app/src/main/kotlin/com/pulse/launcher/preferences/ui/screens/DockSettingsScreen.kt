package com.pulse.launcher.preferences.ui.screens

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.pulse.launcher.preferences.ui.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DockSettingsScreen(onBack: () -> Unit) {
    var iconCount by remember { mutableStateOf(5f) }
    var blur by remember { mutableStateOf(true) }
    var bgColor by remember { mutableStateOf(Color(0xFF1C1B1F)) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Dock") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } })
        }
    ) { padding ->
        LazyColumn(contentPadding = padding) {
            item {
                FancyPrefSeekBar(title = "Icon Count", value = iconCount, valueRange = 3f..7f, steps = 3, onValueChange = { iconCount = it })
            }
            item {
                FancyPrefColorPicker(title = "Background Color", selectedColor = bgColor, onColorSelected = { bgColor = it })
            }
            item {
                FancyPrefSwitch(title = "Blur Background", checked = blur, onCheckedChange = { blur = it })
            }
            item {
                FancyPrefSwitch(title = "Show QSB in Dock", checked = true, onCheckedChange = {})
            }
        }
    }
}
