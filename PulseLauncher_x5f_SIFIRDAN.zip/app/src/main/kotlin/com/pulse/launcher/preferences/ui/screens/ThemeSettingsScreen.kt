package com.pulse.launcher.preferences.ui.screens

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.pulse.launcher.core.animation.AppOpenAnimType
import com.pulse.launcher.core.icon.IconShape
import com.pulse.launcher.preferences.ui.FancyPrefDropdown
import com.pulse.launcher.preferences.ui.FancyPrefSeekBar
import com.pulse.launcher.preferences.ui.FancyPrefSwitch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeSettingsScreen(onBack: () -> Unit) {
    var speed by remember { mutableStateOf(1f) }
    Scaffold(topBar = { TopAppBar(title = { Text("Look & Feel") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }) }) { padding ->
        LazyColumn(contentPadding = padding) {
            item { FancyPrefSeekBar(title = "Transition Speed", value = speed, valueRange = 0.5f..2f, onValueChange = { speed = it }) }
            item { FancyPrefDropdown(title = "App Open Animation", options = AppOpenAnimType.entries, selected = AppOpenAnimType.ZOOM, onSelected = {}) }
            item { FancyPrefDropdown(title = "Icon Shape", options = IconShape.entries, selected = IconShape.SYSTEM, onSelected = {}) }
            item { FancyPrefSwitch(title = "Icon Shadow", checked = true, onCheckedChange = {}) }
            item { FancyPrefSwitch(title = "Dynamic Color (Material You)", subtitle = "Use wallpaper colors", checked = true, onCheckedChange = {}) }
        }
    }
}
