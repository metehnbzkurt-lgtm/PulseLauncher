package com.pulse.launcher.core.icon

import android.content.Context
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.core.graphics.drawable.toBitmap
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.min

enum class IconShape { CIRCLE, SQUIRCLE, ROUNDED_SQUARE, TEARDROP, HEXAGON, SYSTEM }

@Singleton
class AdaptiveIconRenderer @Inject constructor(
    @ApplicationContext private val context: Context,
    private val normalizer: IconNormalizer
) {
    /**
     * Core pipeline:
     * 1. AdaptiveIconDrawable -> separate layers
     * 2. Apply user shape mask
     * 3. Reshape / scale
     * 4. Shadow
     * 5. Normalize size
     */
    fun render(
        drawable: Drawable,
        shape: IconShape = IconShape.SYSTEM,
        addShadow: Boolean = true,
        normalize: Boolean = true,
        sizePx: Int = 192
    ): Bitmap {
        val baseBitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && drawable is AdaptiveIconDrawable) {
            renderAdaptive(drawable, shape, sizePx)
        } else {
            drawable.toBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        }

        var result = baseBitmap

        if (normalize) {
            result = normalizer.normalize(result)
        }

        if (addShadow) {
            result = addShadow(result)
        }

        return result
    }

    private fun renderAdaptive(drawable: AdaptiveIconDrawable, shape: IconShape, size: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, size, size)

        // Create shape path for clipping
        val path = createShapePath(shape, size.toFloat())
        canvas.save()
        if (shape != IconShape.SYSTEM) {
            canvas.clipPath(path)
        }
        drawable.draw(canvas)
        canvas.restore()
        return bitmap
    }

    private fun createShapePath(shape: IconShape, size: Float): Path {
        val path = Path()
        when (shape) {
            IconShape.CIRCLE -> path.addCircle(size/2, size/2, size/2, Path.Direction.CW)
            IconShape.SQUIRCLE -> {
                // superellipse approximation
                val r = size/2
                val c = size * 0.15f
                path.moveTo(c, 0f)
                path.lineTo(size-c, 0f)
                path.quadTo(size, 0f, size, c)
                path.lineTo(size, size-c)
                path.quadTo(size, size, size-c, size)
                path.lineTo(c, size)
                path.quadTo(0f, size, 0f, size-c)
                path.lineTo(0f, c)
                path.quadTo(0f, 0f, c, 0f)
                path.close()
            }
            IconShape.ROUNDED_SQUARE -> {
                path.addRoundRect(0f,0f,size,size, size*0.2f, size*0.2f, Path.Direction.CW)
            }
            IconShape.TEARDROP -> {
                path.addCircle(size*0.5f, size*0.5f, size*0.45f, Path.Direction.CW)
                // teardrop tail
                path.moveTo(size*0.5f, size*0.05f)
            }
            IconShape.HEXAGON -> {
                val center = size/2
                val radius = size/2
                for (i in 0..5) {
                    val angle = Math.toRadians((60*i -30).toDouble())
                    val x = center + radius * Math.cos(angle)
                    val y = center + radius * Math.sin(angle)
                    if (i==0) path.moveTo(x.toFloat(), y.toFloat()) else path.lineTo(x.toFloat(), y.toFloat())
                }
                path.close()
            }
            IconShape.SYSTEM -> { /* no clip */ }
        }
        return path
    }

    private fun addShadow(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            alpha = 30
            maskFilter = BlurMaskFilter(8f, BlurMaskFilter.Blur.NORMAL)
        }
        canvas.drawBitmap(src, 0f, 4f, paint)
        canvas.drawBitmap(src, 0f, 0f, null)
        return out
    }
}
