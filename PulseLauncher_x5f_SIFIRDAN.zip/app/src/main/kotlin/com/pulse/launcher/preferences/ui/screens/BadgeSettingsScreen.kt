package com.pulse.launcher.preferences.ui.screens

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import com.pulse.launcher.features.badges.BadgePosition
import com.pulse.launcher.features.badges.BadgeStyle
import com.pulse.launcher.preferences.ui.FancyPrefColorPicker
import com.pulse.launcher.preferences.ui.FancyPrefDropdown

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BadgeSettingsScreen(onBack: () -> Unit) {
    var style by remember { mutableStateOf(BadgeStyle.NUMBER) }
    var pos by remember { mutableStateOf(BadgePosition.TOP_RIGHT) }
    var color by remember { mutableStateOf(Color.Red) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Notification Badges") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }) }
    ) { padding ->
        LazyColumn(contentPadding = padding) {
            item { FancyPrefDropdown(title = "Badge Style", options = BadgeStyle.entries, selected = style, onSelected = { style = it }) }
            item { FancyPrefDropdown(title = "Position", options = BadgePosition.entries, selected = pos, onSelected = { pos = it }) }
            item { FancyPrefColorPicker(title = "Badge Color", selectedColor = color, onColorSelected = { color = it }) }
        }
    }
}
