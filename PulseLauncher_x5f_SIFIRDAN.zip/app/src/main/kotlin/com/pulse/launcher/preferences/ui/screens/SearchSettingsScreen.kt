package com.pulse.launcher.preferences.ui.screens

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.pulse.launcher.preferences.ui.FancyPrefSwitch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchSettingsScreen(onBack: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("Search") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }) }) { padding ->
        LazyColumn(contentPadding = padding) {
            item { FancyPrefSwitch(title = "Global Search", subtitle = "Apps, contacts, web", checked = true, onCheckedChange = {}) }
            item { FancyPrefSwitch(title = "Show Quick Search Bar", checked = true, onCheckedChange = {}) }
            item { FancyPrefSwitch(title = "Sesame Integration", subtitle = "Shortcuts & deep search", checked = false, onCheckedChange = {}) }
        }
    }
}
