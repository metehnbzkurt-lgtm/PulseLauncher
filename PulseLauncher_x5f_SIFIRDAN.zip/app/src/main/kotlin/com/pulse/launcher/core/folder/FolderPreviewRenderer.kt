package com.pulse.launcher.core.folder

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp

@Composable
fun FolderPreviewRenderer(
    iconCount: Int,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(56.dp)
            .clip(MaterialTheme.shapes.medium)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(6.dp)
    ) {
        // Simplified 2x2 preview grid
        Column {
            Row { repeat(minOf(2, iconCount)) { Box(Modifier.size(18.dp).background(MaterialTheme.colorScheme.primary)) } }
            Row { repeat(minOf(2, (iconCount-2).coerceAtLeast(0))) { Box(Modifier.size(18.dp).background(MaterialTheme.colorScheme.secondary)) } }
        }
    }
}
