package com.pulse.launcher.core.model
typealias WorkspaceItemModel = WorkspaceItem
