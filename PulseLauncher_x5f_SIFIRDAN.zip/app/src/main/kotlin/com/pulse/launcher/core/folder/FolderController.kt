package com.pulse.launcher.core.folder

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FolderController @Inject constructor() {
    private val _openFolderId = MutableStateFlow<Long?>(null)
    val openFolderId: StateFlow<Long?> = _openFolderId

    fun open(folderId: Long) { _openFolderId.value = folderId }
    fun close() { _openFolderId.value = null }
}
