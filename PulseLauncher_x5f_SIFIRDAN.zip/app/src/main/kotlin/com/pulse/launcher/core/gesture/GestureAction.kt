package com.pulse.launcher.core.gesture

enum class GestureType {
    SWIPE_UP,
    SWIPE_DOWN,
    DOUBLE_TAP,
    PINCH_IN,
    PINCH_OUT,
    TWO_FINGER_SWIPE,
    LONG_PRESS,
    HOME_PRESS
}

enum class GestureAction(val displayName: String) {
    NONE("None"),
    OPEN_DRAWER("Open App Drawer"),
    OPEN_SEARCH("Open Search"),
    OPEN_APP_SEARCH("Open App Search"),
    SCREEN_OFF("Screen Off"),
    TOGGLE_NOTIFICATIONS("Toggle Notifications"),
    OPEN_APP_SPECIFIC("Open Specific App"),
    GO_TO_PAGE("Go To Page"),
    OPEN_FOLDER("Open Folder"),
    TOGGLE_DOCK("Toggle Dock"),
    OPEN_RECENT_APPS("Open Recent Apps"),
    CUSTOM_INTENT("Custom Intent");

    companion object {
        fun fromDisplayName(name: String): GestureAction =
            entries.find { it.displayName == name } ?: NONE
    }
}

data class GestureConfig(
    val type: GestureType,
    val action: GestureAction,
    val extra: String? = null // e.g., packageName for OPEN_APP_SPECIFIC, page index for GO_TO_PAGE
)
