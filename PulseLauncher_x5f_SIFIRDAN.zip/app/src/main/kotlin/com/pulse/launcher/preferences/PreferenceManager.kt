package com.pulse.launcher.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import com.pulse.launcher.core.gesture.GestureAction
import com.pulse.launcher.core.gesture.GestureType
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "pulse_prefs")

@Singleton
class PreferenceManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val dataStore = context.dataStore

    // Generic flows
    fun <T> getFlow(key: Preferences.Key<T>, default: T): Flow<T> =
        dataStore.data.map { it[key] ?: default }

    suspend fun <T> set(key: Preferences.Key<T>, value: T) {
        dataStore.edit { it[key] = value }
    }

    suspend fun <T> get(key: Preferences.Key<T>, default: T): T {
        return dataStore.data.map { it[key] ?: default }.first()
    }

    // Gesture helpers
    fun getGestureFlow(type: GestureType): Flow<GestureAction> {
        val key = when (type) {
            GestureType.SWIPE_UP -> PreferenceKeys.GESTURE_SWIPE_UP
            GestureType.SWIPE_DOWN -> PreferenceKeys.GESTURE_SWIPE_DOWN
            GestureType.DOUBLE_TAP -> PreferenceKeys.GESTURE_DOUBLE_TAP
            GestureType.PINCH_IN -> PreferenceKeys.GESTURE_PINCH_IN
            GestureType.PINCH_OUT -> PreferenceKeys.GESTURE_PINCH_OUT
            GestureType.TWO_FINGER_SWIPE -> PreferenceKeys.GESTURE_TWO_FINGER_SWIPE_UP
            GestureType.LONG_PRESS -> PreferenceKeys.GESTURE_LONG_PRESS
            GestureType.HOME_PRESS -> PreferenceKeys.GESTURE_HOME_BUTTON
        }
        return dataStore.data.map { prefs ->
            val name = prefs[key] ?: GestureAction.NONE.name
            runCatching { GestureAction.valueOf(name) }.getOrDefault(GestureAction.NONE)
        }
    }

    suspend fun getGesture(type: GestureType): GestureAction {
        return getGestureFlow(type).first()
    }

    suspend fun setGesture(type: GestureType, action: GestureAction) {
        val key = when (type) {
            GestureType.SWIPE_UP -> PreferenceKeys.GESTURE_SWIPE_UP
            GestureType.SWIPE_DOWN -> PreferenceKeys.GESTURE_SWIPE_DOWN
            GestureType.DOUBLE_TAP -> PreferenceKeys.GESTURE_DOUBLE_TAP
            GestureType.PINCH_IN -> PreferenceKeys.GESTURE_PINCH_IN
            GestureType.PINCH_OUT -> PreferenceKeys.GESTURE_PINCH_OUT
            GestureType.TWO_FINGER_SWIPE -> PreferenceKeys.GESTURE_TWO_FINGER_SWIPE_UP
            GestureType.LONG_PRESS -> PreferenceKeys.GESTURE_LONG_PRESS
            GestureType.HOME_PRESS -> PreferenceKeys.GESTURE_HOME_BUTTON
        }
        set(key, action.name)
    }

    // Desktop defaults
    val desktopColumns: Flow<Int> = getFlow(PreferenceKeys.DESKTOP_GRID_COLUMNS, 5)
    val desktopRows: Flow<Int> = getFlow(PreferenceKeys.DESKTOP_GRID_ROWS, 5)
    val infiniteScroll: Flow<Boolean> = getFlow(PreferenceKeys.DESKTOP_INFINITE_SCROLL, true)
    val iconSize: Flow<Int> = getFlow(PreferenceKeys.DESKTOP_ICON_SIZE, 72)
}
