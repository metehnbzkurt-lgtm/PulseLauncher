package com.pulse.launcher.preferences.ui.screens

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.pulse.launcher.features.nightmode.NightModeType
import com.pulse.launcher.preferences.ui.FancyPrefDropdown
import com.pulse.launcher.preferences.ui.FancyPrefSwitch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NightModeSettingsScreen(onBack: () -> Unit) {
    var enabled by remember { mutableStateOf(false) }
    var type by remember { mutableStateOf(NightModeType.AUTO) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Night Mode") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }) }
    ) { padding ->
        LazyColumn(contentPadding = padding) {
            item { FancyPrefSwitch(title = "Enable Night Mode", checked = enabled, onCheckedChange = { enabled = it }) }
            item {
                FancyPrefDropdown(
                    title = "Night Mode Type",
                    subtitle = "Auto / Location / Custom Time",
                    options = NightModeType.entries,
                    selected = type,
                    onSelected = { type = it }
                )
            }
            if (type == NightModeType.CUSTOM) {
                item { ListItem(headlineContent = { Text("Start: 22:00") }) }
                item { ListItem(headlineContent = { Text("End: 07:00") }) }
            }
        }
    }
}
