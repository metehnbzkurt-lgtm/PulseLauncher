package com.pulse.launcher.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.pulse.launcher.data.database.dao.DrawerGroupDao
import com.pulse.launcher.data.database.dao.FavoriteDao
import com.pulse.launcher.data.database.dao.ShortcutDao
import com.pulse.launcher.data.database.entity.DrawerGroupEntity
import com.pulse.launcher.data.database.entity.FavoriteEntity
import com.pulse.launcher.data.database.entity.ShortcutEntity

@Database(
    entities = [FavoriteEntity::class, DrawerGroupEntity::class, ShortcutEntity::class],
    version = 1,
    exportSchema = true
)
abstract class PulseDatabase : RoomDatabase() {
    abstract fun favoriteDao(): FavoriteDao
    abstract fun drawerGroupDao(): DrawerGroupDao
    abstract fun shortcutDao(): ShortcutDao
}
