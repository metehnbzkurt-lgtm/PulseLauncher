package com.pulse.launcher.core.model

sealed class LauncherItem {
    abstract val id: Long
}

data class AppInfo(
    override val id: Long = 0,
    val componentName: String, // flattened ComponentName
    val packageName: String,
    val label: String,
    val isWorkProfile: Boolean = false,
    val userId: Int = 0
) : LauncherItem()

data class WorkspaceItem(
    override val id: Long,
    val container: Long, // -100 desktop, -101 hotseat, folderId
    val screenId: Int,
    val cellX: Int,
    val cellY: Int,
    val spanX: Int = 1,
    val spanY: Int = 1,
    val appInfo: AppInfo? = null,
    val title: String? = null,
    val customIcon: ByteArray? = null
) : LauncherItem()

data class FolderInfo(
    override val id: Long,
    val title: String,
    val container: Long,
    val screenId: Int,
    val cellX: Int,
    val cellY: Int,
    val contents: List<WorkspaceItem> = emptyList()
) : LauncherItem()
