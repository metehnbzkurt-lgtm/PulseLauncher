package com.pulse.launcher.preferences.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupSettingsScreen(onBack: () -> Unit, onExport: () -> Unit = {}, onImport: () -> Unit = {}) {
    Scaffold(topBar = { TopAppBar(title = { Text("Backup & Restore") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onExport, modifier = Modifier.fillMaxWidth()) { Text("Export to File (SAF)") }
            Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Text("Import from File") }
            Text("Backups include desktop layout, dock, drawer groups and settings.", style = MaterialTheme.typography.bodySmall)
        }
    }
}
