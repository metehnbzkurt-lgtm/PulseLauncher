package com.pulse.launcher.core.gesture

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.delay

/**
 * Compose gesture detection modifier that forwards to GestureController.
 * Supports double tap, long press, pinch in/out, swipe up/down via drag thresholds.
 */
fun Modifier.pulseGestures(
    controller: GestureController
): Modifier = this
    .pointerInput(Unit) {
        detectTapGestures(
            onDoubleTap = { controller.onDoubleTap() },
            onLongPress = { controller.onLongPress() }
        )
    }
    .pointerInput(Unit) {
        var lastZoom = 1f
        detectTransformGestures { _, _, zoom, _ ->
            if (zoom < 0.9f && lastZoom >= 0.9f) controller.onPinchIn()
            if (zoom > 1.1f && lastZoom <= 1.1f) controller.onPinchOut()
            lastZoom = zoom
        }
    }
