package com.pulse.launcher.preferences.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.pulse.launcher.navigation.Routes

data class SettingsItem(val title: String, val subtitle: String, val route: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsHostScreen(onBack: () -> Unit) {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "list") {
        composable("list") {
            SettingsListScreen(
                onBack = onBack,
                onItemClick = { route -> nav.navigate(route) }
            )
        }
        composable(Routes.DESKTOP_SETTINGS) { DesktopSettingsScreen(onBack = { nav.popBackStack() }) }
        composable(Routes.DRAWER_SETTINGS) { DrawerSettingsScreen(onBack = { nav.popBackStack() }) }
        composable(Routes.DOCK_SETTINGS) { DockSettingsScreen(onBack = { nav.popBackStack() }) }
        composable(Routes.GESTURE_SETTINGS) { GestureSettingsScreen(onBack = { nav.popBackStack() }) }
        composable(Routes.NIGHT_MODE_SETTINGS) { NightModeSettingsScreen(onBack = { nav.popBackStack() }) }
        composable(Routes.BADGE_SETTINGS) { BadgeSettingsScreen(onBack = { nav.popBackStack() }) }
        composable(Routes.SEARCH_SETTINGS) { SearchSettingsScreen(onBack = { nav.popBackStack() }) }
        composable(Routes.THEME_SETTINGS) { ThemeSettingsScreen(onBack = { nav.popBackStack() }) }
        composable(Routes.BACKUP_SETTINGS) { BackupSettingsScreen(onBack = { nav.popBackStack() }) }
        composable(Routes.LABS_SETTINGS) { LabsSettingsScreen(onBack = { nav.popBackStack() }) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsListScreen(onBack: () -> Unit, onItemClick: (String) -> Unit) {
    val items = remember {
        listOf(
            SettingsItem("Desktop", "Grid, scroll effects, labels", Routes.DESKTOP_SETTINGS, Icons.Default.DesktopWindows),
            SettingsItem("App Drawer", "Style, tabs, groups", Routes.DRAWER_SETTINGS, Icons.Default.Apps),
            SettingsItem("Dock", "Icons, background, blur", Routes.DOCK_SETTINGS, Icons.Default.Dock),
            SettingsItem("Gestures", "Swipe, pinch, double tap", Routes.GESTURE_SETTINGS, Icons.Default.Gesture),
            SettingsItem("Look & Feel", "Animations, icon shape", Routes.THEME_SETTINGS, Icons.Default.Palette),
            SettingsItem("Night Mode", "Auto darkening", Routes.NIGHT_MODE_SETTINGS, Icons.Default.DarkMode),
            SettingsItem("Badges", "Dot / Number", Routes.BADGE_SETTINGS, Icons.Default.Notifications),
            SettingsItem("Search", "QSB & global search", Routes.SEARCH_SETTINGS, Icons.Default.Search),
            SettingsItem("Backup & Restore", "Export / Import", Routes.BACKUP_SETTINGS, Icons.Default.Backup),
            SettingsItem("Labs", "Experimental", Routes.LABS_SETTINGS, Icons.Default.Science),
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Pulse Settings", style = MaterialTheme.typography.headlineMedium) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }
            )
        }
    ) { padding ->
        LazyColumn(contentPadding = padding) {
            items(items.size) { idx ->
                val item = items[idx]
                ListItem(
                    headlineContent = { Text(item.title, style = MaterialTheme.typography.titleMedium) },
                    supportingContent = { Text(item.subtitle) },
                    leadingContent = { Icon(item.icon, null) },
                    modifier = Modifier.clickable { onItemClick(item.route) }.padding(vertical = 4.dp)
                )
                HorizontalDivider()
            }
        }
    }
}
