package com.pulse.launcher.core.animation

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TransitionManager @Inject constructor() {
    var speedFactor: Float = 1f
    fun getDuration(baseMs: Long): Long = (baseMs / speedFactor).toLong().coerceAtLeast(80)
}
