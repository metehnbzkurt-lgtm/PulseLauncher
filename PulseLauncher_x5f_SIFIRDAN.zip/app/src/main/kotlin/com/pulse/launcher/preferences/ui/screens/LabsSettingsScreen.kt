package com.pulse.launcher.preferences.ui.screens

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import com.pulse.launcher.preferences.ui.FancyPrefSwitch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LabsSettingsScreen(onBack: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("Labs (Experimental)") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }) }) { padding ->
        LazyColumn(contentPadding = padding) {
            item { FancyPrefSwitch(title = "Widget Corner Radius Override", subtitle = "Force rounded widgets", checked = false, onCheckedChange = {}) }
            item { FancyPrefSwitch(title = "Parallax Wallpaper", checked = true, onCheckedChange = {}) }
            item { FancyPrefSwitch(title = "Predictive Back Gesture", checked = true, onCheckedChange = {}) }
            item { FancyPrefSwitch(title = "120fps Animations", subtitle = "Uncapped frame rate", checked = false, onCheckedChange = {}) }
        }
    }
}
