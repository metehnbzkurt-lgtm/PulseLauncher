package com.pulse.launcher.features.nightmode

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import com.pulse.launcher.preferences.PreferenceKeys
import com.pulse.launcher.preferences.PreferenceManager
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalTime
import javax.inject.Inject
import javax.inject.Singleton

enum class NightModeType { AUTO, LOCATION, CUSTOM, DISABLED }

@Singleton
class NightModeManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val prefs: PreferenceManager
) {
    val isNightMode: Flow<Boolean> = prefs.getFlow(PreferenceKeys.NIGHT_MODE_ENABLED, false)

    fun shouldUseDarkTheme(systemDark: Boolean, nightModeEnabled: Boolean, type: NightModeType): Boolean {
        return when (type) {
            NightModeType.AUTO -> systemDark
            NightModeType.CUSTOM -> nightModeEnabled // check time window elsewhere
            NightModeType.LOCATION -> systemDark // simplified: use sunset calc
            NightModeType.DISABLED -> false
        }
    }

    fun isInCustomWindow(start: String, end: String): Boolean {
        return try {
            val now = LocalTime.now()
            val s = LocalTime.parse(start)
            val e = LocalTime.parse(end)
            if (s.isBefore(e)) now.isAfter(s) && now.isBefore(e)
            else now.isAfter(s) || now.isBefore(e)
        } catch (e: Exception) { false }
    }
}
