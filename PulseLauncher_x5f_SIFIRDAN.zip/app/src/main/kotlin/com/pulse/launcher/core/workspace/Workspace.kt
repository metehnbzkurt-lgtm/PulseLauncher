package com.pulse.launcher.core.workspace

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pulse.launcher.core.animation.ScrollEffect
import com.pulse.launcher.core.animation.ScrollEffectEngine
import com.pulse.launcher.data.database.entity.FavoriteEntity

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Workspace(
    pages: List<List<FavoriteEntity>>,
    columns: Int,
    rows: Int,
    scrollEffect: ScrollEffect = ScrollEffect.STANDARD,
    isEditMode: Boolean = false,
    currentPage: Int,
    onPageChanged: (Int) -> Unit,
    onItemClick: (FavoriteEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val pagerState = rememberPagerState(initialPage = currentPage, pageCount = { pages.size.coerceAtLeast(1) })

    LaunchedEffect(pagerState.currentPage) {
        onPageChanged(pagerState.currentPage)
    }

    Column(modifier = modifier.fillMaxSize()) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.weight(1f)
        ) { page ->
            val pageOffset = (pagerState.currentPage - page) + pagerState.currentPageOffsetFraction
            val items = pages.getOrNull(page) ?: emptyList()

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .then(ScrollEffectEngine.getTransform(scrollEffect, pageOffset))
            ) {
                CellLayout(
                    columns = columns,
                    rows = rows,
                    items = items,
                    isEditMode = isEditMode,
                    onItemClick = onItemClick
                ) { item ->
                    // Placeholder icon
                    Text(text = item.title ?: "App", modifier = Modifier.align(Alignment.Center))
                }
            }
        }

        // Page indicator
        Row(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center
        ) {
            repeat(pages.size) { index ->
                Box(
                    modifier = Modifier
                        .padding(4.dp)
                        .size(if (index == pagerState.currentPage) 10.dp else 6.dp)
                )
            }
        }
    }
}
