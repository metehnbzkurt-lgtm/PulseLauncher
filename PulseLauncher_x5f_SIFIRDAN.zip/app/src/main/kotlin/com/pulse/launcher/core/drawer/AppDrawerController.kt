package com.pulse.launcher.core.drawer

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

enum class DrawerStyle { VERTICAL, HORIZONTAL, CARD }

@Singleton
class AppDrawerController @Inject constructor() {
    private val _isOpen = MutableStateFlow(false)
    val isOpen: StateFlow<Boolean> = _isOpen

    private val _style = MutableStateFlow(DrawerStyle.VERTICAL)
    val style: StateFlow<DrawerStyle> = _style

    fun open() { _isOpen.value = true }
    fun close() { _isOpen.value = false }
    fun toggle() { _isOpen.value = !_isOpen.value }
    fun setStyle(style: DrawerStyle) { _style.value = style }
}
