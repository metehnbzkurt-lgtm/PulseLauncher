package com.pulse.launcher.data.database.dao

import androidx.room.*
import com.pulse.launcher.data.database.entity.DrawerGroupEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DrawerGroupDao {
    @Query("SELECT * FROM drawer_groups ORDER BY tabOrder ASC")
    fun getAllFlow(): Flow<List<DrawerGroupEntity>>

    @Query("SELECT * FROM drawer_groups ORDER BY tabOrder ASC")
    suspend fun getAll(): List<DrawerGroupEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: DrawerGroupEntity): Long

    @Delete
    suspend fun delete(entity: DrawerGroupEntity)

    @Query("DELETE FROM drawer_groups")
    suspend fun clearAll()
}
