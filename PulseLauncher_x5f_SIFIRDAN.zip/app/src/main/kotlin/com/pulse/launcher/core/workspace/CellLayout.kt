package com.pulse.launcher.core.workspace

import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.unit.IntOffset
import com.pulse.launcher.data.database.entity.FavoriteEntity

@Composable
fun CellLayout(
    columns: Int,
    rows: Int,
    items: List<FavoriteEntity>,
    isEditMode: Boolean,
    modifier: Modifier = Modifier,
    onItemMove: (Long, Int, Int) -> Unit = { _,_,_ -> },
    onItemClick: (FavoriteEntity) -> Unit = {},
    onItemLongClick: (FavoriteEntity) -> Unit = {},
    content: @Composable (FavoriteEntity) -> Unit
) {
    // Simplified subgrid calculation
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val cellWidth = maxWidth / columns
        val cellHeight = maxHeight / rows

        Box(modifier = Modifier.fillMaxSize()) {
            items.forEach { item ->
                key(item.id) {
                    Box(
                        modifier = Modifier
                            .offset {
                                IntOffset(
                                    (item.cellX * cellWidth.toPx()).toInt(),
                                    (item.cellY * cellHeight.toPx()).toInt()
                                )
                            }
                            .size(cellWidth, cellHeight)
                    ) {
                        content(item)
                    }
                }
            }
        }
    }
}

private fun androidx.compose.ui.unit.Dp.toPx(): Float = this.value * 3f // simplified, real uses LocalDensity
