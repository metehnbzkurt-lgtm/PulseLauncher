package com.pulse.launcher.data.repository

import com.pulse.launcher.preferences.PreferenceManager
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PreferenceRepository @Inject constructor(
    private val prefs: PreferenceManager
) {
    fun desktopColumns() = prefs.desktopColumns
}
