package com.pulse.launcher.core.workspace

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.pulse.launcher.data.database.entity.FavoriteEntity

@Composable
fun Hotseat(
    items: List<FavoriteEntity>,
    iconCount: Int = 5,
    showBlur: Boolean = true,
    backgroundColor: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
    modifier: Modifier = Modifier,
    onItemClick: (FavoriteEntity) -> Unit = {},
    itemContent: @Composable (FavoriteEntity) -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(88.dp)
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(backgroundColor)
            .then(if (showBlur) Modifier.blur(12.dp) else Modifier)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.take(iconCount).forEach { item ->
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    itemContent(item)
                }
            }
        }
    }
}
