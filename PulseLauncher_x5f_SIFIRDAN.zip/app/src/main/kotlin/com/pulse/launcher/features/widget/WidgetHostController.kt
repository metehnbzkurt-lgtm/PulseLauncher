package com.pulse.launcher.features.widget

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WidgetHostController @Inject constructor(
    @ApplicationContext context: Context
) {
    private val appWidgetManager = AppWidgetManager.getInstance(context)
    private val appWidgetHost = AppWidgetHost(context, 1024)

    fun startListening() { appWidgetHost.startListening() }
    fun stopListening() { appWidgetHost.stopListening() }
    fun allocateId(): Int = appWidgetHost.allocateAppWidgetId()
    fun deleteId(id: Int) = appWidgetHost.deleteAppWidgetId(id)
}
