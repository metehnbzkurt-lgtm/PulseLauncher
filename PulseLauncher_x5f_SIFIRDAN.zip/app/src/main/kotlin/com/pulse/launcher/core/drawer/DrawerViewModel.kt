package com.pulse.launcher.core.drawer

import android.content.Context
import android.content.pm.LauncherApps
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pulse.launcher.core.model.AppInfo
import com.pulse.launcher.preferences.PreferenceManager
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DrawerViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val prefs: PreferenceManager,
    private val tabManager: DrawerTabManager
) : ViewModel() {

    private val _allApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val allApps: StateFlow<List<AppInfo>> = _allApps

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    val filteredApps = combine(_allApps, _searchQuery, tabManager.selectedTab) { apps, query, tab ->
        var list = apps
        if (tab != null) {
            list = tabManager.filterByTab(list, tab)
        }
        if (query.isNotBlank()) {
            list = list.filter { it.label.contains(query, ignoreCase = true) }
        }
        list.sortedBy { it.label.lowercase() }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tabs = tabManager.tabsFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(), emptyList())

    fun loadApps() {
        viewModelScope.launch {
            val launcherApps = context.getSystemService(LauncherApps::class.java)
            val user = android.os.Process.myUserHandle()
            val apps = launcherApps.getActivityList(null, user).map {
                AppInfo(
                    componentName = "${it.componentName.packageName}/${it.componentName.className}",
                    packageName = it.componentName.packageName,
                    label = it.label.toString()
                )
            }
            _allApps.value = apps
        }
    }

    fun setQuery(q: String) { _searchQuery.value = q }
}
