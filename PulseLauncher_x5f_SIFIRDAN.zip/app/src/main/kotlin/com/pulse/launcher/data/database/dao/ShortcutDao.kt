package com.pulse.launcher.data.database.dao

import androidx.room.*
import com.pulse.launcher.data.database.entity.ShortcutEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ShortcutDao {
    @Query("SELECT * FROM shortcuts ORDER BY rank ASC")
    fun getAllFlow(): Flow<List<ShortcutEntity>>

    @Query("SELECT * FROM shortcuts WHERE packageName = :pkg")
    suspend fun getByPackage(pkg: String): List<ShortcutEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entities: List<ShortcutEntity>)

    @Query("DELETE FROM shortcuts WHERE packageName = :pkg")
    suspend fun deleteByPackage(pkg: String)
}
