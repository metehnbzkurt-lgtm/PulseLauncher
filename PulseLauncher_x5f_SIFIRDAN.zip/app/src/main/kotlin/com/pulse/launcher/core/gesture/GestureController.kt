package com.pulse.launcher.core.gesture

import android.content.Context
import android.content.Intent
import com.pulse.launcher.core.drawer.AppDrawerController
import com.pulse.launcher.features.badges.BadgeManager
import com.pulse.launcher.features.screenoff.ScreenOffManager
import com.pulse.launcher.features.search.SearchController
import com.pulse.launcher.preferences.PreferenceManager
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GestureController @Inject constructor(
    @ApplicationContext private val context: Context,
    private val preferenceManager: PreferenceManager,
    private val drawerController: AppDrawerController,
    private val searchController: SearchController,
    private val screenOffManager: ScreenOffManager,
    private val badgeManager: BadgeManager
) {
    private val scope = CoroutineScope(Dispatchers.Main)

    fun onSwipeUp() = handle(GestureType.SWIPE_UP)
    fun onSwipeDown() = handle(GestureType.SWIPE_DOWN)
    fun onDoubleTap() = handle(GestureType.DOUBLE_TAP)
    fun onPinchIn() = handle(GestureType.PINCH_IN)
    fun onPinchOut() = handle(GestureType.PINCH_OUT)
    fun onTwoFingerSwipe() = handle(GestureType.TWO_FINGER_SWIPE)
    fun onLongPress() = handle(GestureType.LONG_PRESS)
    fun onHomePress() = handle(GestureType.HOME_PRESS)

    private fun handle(type: GestureType) {
        scope.launch {
            val action = preferenceManager.getGesture(type)
            execute(action, extra = null)
        }
    }

    suspend fun execute(action: GestureAction, extra: Any? = null) {
        when (action) {
            GestureAction.NONE -> Unit
            GestureAction.OPEN_DRAWER -> drawerController.open()
            GestureAction.OPEN_SEARCH -> searchController.openGlobalSearch()
            GestureAction.OPEN_APP_SEARCH -> searchController.openAppSearch()
            GestureAction.SCREEN_OFF -> screenOffManager.turnOff()
            GestureAction.TOGGLE_NOTIFICATIONS -> toggleNotifications()
            GestureAction.OPEN_APP_SPECIFIC -> {
                val pkg = extra as? String ?: return
                launchApp(pkg)
            }
            GestureAction.GO_TO_PAGE -> {
                val page = (extra as? Int) ?: 0
                // Workspace navigation via event bus / shared flow
            }
            GestureAction.OPEN_FOLDER -> { /* FolderController */ }
            GestureAction.TOGGLE_DOCK -> { /* dock visibility */ }
            GestureAction.OPEN_RECENT_APPS -> openRecents()
            GestureAction.CUSTOM_INTENT -> {
                val intentStr = extra as? String ?: return
                try {
                    val intent = Intent.parseUri(intentStr, 0)
                    context.startActivity(intent.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
                } catch (e: Exception) { /* log */ }
            }
        }
    }

    private fun launchApp(packageName: String) {
        val launch = context.packageManager.getLaunchIntentForPackage(packageName) ?: return
        context.startActivity(launch.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
    }

    private fun openRecents() {
        // Requires system permission, best-effort
        try {
            val intent = Intent("com.android.systemui.action.TOGGLE_RECENTS")
            context.sendBroadcast(intent)
        } catch (e: Exception) { }
    }

    private fun toggleNotifications() {
        try {
            context.sendBroadcast(Intent("com.pulse.launcher.TOGGLE_NOTIFICATION_PANEL"))
        } catch (e: Exception) {}
    }
}
