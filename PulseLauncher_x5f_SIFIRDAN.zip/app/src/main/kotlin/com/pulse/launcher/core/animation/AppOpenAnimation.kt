package com.pulse.launcher.core.animation

import androidx.compose.animation.core.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer

enum class AppOpenAnimType { ZOOM, FADE, SLIDE_UP, SCALE, NONE }

@Composable
fun Modifier.appOpenAnimation(
    type: AppOpenAnimType,
    progress: Float // 0..1
): Modifier {
    return this.graphicsLayer {
        when (type) {
            AppOpenAnimType.ZOOM -> {
                scaleX = 0.8f + progress * 0.2f
                scaleY = 0.8f + progress * 0.2f
                alpha = progress
            }
            AppOpenAnimType.FADE -> alpha = progress
            AppOpenAnimType.SLIDE_UP -> {
                translationY = (1f - progress) * 200f
                alpha = progress
            }
            AppOpenAnimType.SCALE -> {
                scaleX = progress
                scaleY = progress
            }
            AppOpenAnimType.NONE -> {}
        }
    }
}
