package com.pulse.launcher.core.icon

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.max

@Singleton
class IconNormalizer @Inject constructor() {
    /**
     * Equalize visual weight of icons by scaling based on non-transparent bounds.
     */
    fun normalize(bitmap: Bitmap): Bitmap {
        val bounds = getAlphaBounds(bitmap) ?: return bitmap
        val maxDim = max(bounds.width(), bounds.height())
        val target = (bitmap.width * 0.7f).toInt() // 70% of canvas is normalized size
        val scale = target.toFloat() / maxDim

        val out = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val dst = Rect(
            ((bitmap.width - bounds.width()*scale)/2).toInt(),
            ((bitmap.height - bounds.height()*scale)/2).toInt(),
            ((bitmap.width + bounds.width()*scale)/2).toInt(),
            ((bitmap.height + bounds.height()*scale)/2).toInt()
        )
        canvas.drawBitmap(bitmap, bounds, dst, null)
        return out
    }

    private fun getAlphaBounds(bm: Bitmap): Rect? {
        var left = bm.width
        var top = bm.height
        var right = 0
        var bottom = 0
        for (y in 0 until bm.height step 2) {
            for (x in 0 until bm.width step 2) {
                if ((bm.getPixel(x,y) ushr 24) > 10) {
                    if (x < left) left = x
                    if (x > right) right = x
                    if (y < top) top = y
                    if (y > bottom) bottom = y
                }
            }
        }
        if (right <= left) return null
        return Rect(left, top, right, bottom)
    }
}
