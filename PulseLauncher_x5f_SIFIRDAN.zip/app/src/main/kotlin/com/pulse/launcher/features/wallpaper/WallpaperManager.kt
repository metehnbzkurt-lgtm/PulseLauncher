package com.pulse.launcher.features.wallpaper

import android.app.WallpaperManager
import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PulseWallpaperManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val wm = WallpaperManager.getInstance(context)

    fun setWallpaperOffset(xOffset: Float) {
        // Wallpaper scroll / parallax
        // Requires window.setWallpaperOffsets
    }

    fun enableScroll(enable: Boolean) {
        // Persist preference; real implementation uses WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER
    }
}
