package com.pulse.launcher.features.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ThemeManager @Inject constructor() {
    // Dynamic color will be handled via MaterialTheme in Compose
    @Composable
    fun getColorScheme(isDark: Boolean): ColorScheme {
        return if (isDark) darkColorScheme() else lightColorScheme()
    }
}
