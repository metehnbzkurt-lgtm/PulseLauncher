package com.pulse.launcher.data.database.dao

import androidx.room.*
import com.pulse.launcher.data.database.entity.FavoriteEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites ORDER BY container, screen, cellY, cellX")
    fun getAllFlow(): Flow<List<FavoriteEntity>>

    @Query("SELECT * FROM favorites WHERE container = :container ORDER BY screen, cellY, cellX")
    suspend fun getByContainer(container: Long): List<FavoriteEntity>

    @Query("SELECT * FROM favorites WHERE id = :id")
    suspend fun getById(id: Long): FavoriteEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: FavoriteEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entities: List<FavoriteEntity>)

    @Update
    suspend fun update(entity: FavoriteEntity)

    @Delete
    suspend fun delete(entity: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM favorites")
    suspend fun clearAll()

    @Query("SELECT * FROM favorites WHERE container = :folderId")
    suspend fun getFolderContents(folderId: Long): List<FavoriteEntity>
}
