package com.pulse.launcher.navigation

object Routes {
    const val HOME = "home"
    const val SETTINGS = "settings"
    const val DESKTOP_SETTINGS = "desktop_settings"
    const val DRAWER_SETTINGS = "drawer_settings"
    const val DOCK_SETTINGS = "dock_settings"
    const val GESTURE_SETTINGS = "gesture_settings"
    const val NIGHT_MODE_SETTINGS = "night_mode_settings"
    const val BADGE_SETTINGS = "badge_settings"
    const val SEARCH_SETTINGS = "search_settings"
    const val THEME_SETTINGS = "theme_settings"
    const val BACKUP_SETTINGS = "backup_settings"
    const val LABS_SETTINGS = "labs_settings"
}
