package com.pulse.launcher.core.icon

import android.content.Context
import android.content.pm.LauncherApps
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.os.UserManager
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class IconCache @Inject constructor(
    @ApplicationContext private val context: Context,
    private val renderer: AdaptiveIconRenderer,
    private val themeManager: IconThemeManager
) {
    private val cache = mutableMapOf<String, Bitmap>()
    private val mutex = Mutex()

    suspend fun getIcon(componentName: String, shape: IconShape = IconShape.SYSTEM): Bitmap {
        mutex.withLock {
            cache[componentName]?.let { return it }
        }
        // Try theme pack first
        val themed = themeManager.getThemedIcon(componentName)
        val drawable: Drawable? = themed ?: run {
            try {
                val parts = componentName.split("/")
                val pkg = parts[0]
                val cls = if (parts.size>1) parts[1] else ""
                context.packageManager.getActivityIcon(
                    android.content.ComponentName(pkg, cls)
                )
            } catch (e: Exception) {
                context.packageManager.defaultActivityIcon
            }
        }

        val bitmap = renderer.render(drawable!!, shape)
        mutex.withLock { cache[componentName] = bitmap }
        return bitmap
    }

    suspend fun clear() {
        mutex.withLock { cache.clear() }
    }
}
