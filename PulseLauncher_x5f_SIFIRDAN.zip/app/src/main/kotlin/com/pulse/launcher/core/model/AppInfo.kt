package com.pulse.launcher.core.model
// Alias kept for compatibility with diagram
typealias AppInfoModel = AppInfo
