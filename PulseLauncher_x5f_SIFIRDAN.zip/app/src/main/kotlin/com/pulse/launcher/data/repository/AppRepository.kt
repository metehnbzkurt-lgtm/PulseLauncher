package com.pulse.launcher.data.repository

import android.content.Context
import android.content.pm.LauncherApps
import com.pulse.launcher.core.model.AppInfo
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AppRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    fun getInstalledApps(): List<AppInfo> {
        val launcherApps = context.getSystemService(LauncherApps::class.java)
        val user = android.os.Process.myUserHandle()
        return launcherApps.getActivityList(null, user).map {
            AppInfo(
                componentName = "${it.componentName.packageName}/${it.componentName.className}",
                packageName = it.componentName.packageName,
                label = it.label.toString()
            )
        }
    }
}
