package com.pulse.launcher.core.workspace

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pulse.launcher.data.database.dao.FavoriteDao
import com.pulse.launcher.data.database.entity.FavoriteEntity
import com.pulse.launcher.preferences.PreferenceManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class WorkspaceViewModel @Inject constructor(
    private val favoriteDao: FavoriteDao,
    private val prefs: PreferenceManager
) : ViewModel() {

    val favorites = favoriteDao.getAllFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val columns = prefs.desktopColumns.stateIn(viewModelScope, SharingStarted.WhileSubscribed(), 5)
    val rows = prefs.desktopRows.stateIn(viewModelScope, SharingStarted.WhileSubscribed(), 5)
    val infiniteScroll = prefs.infiniteScroll.stateIn(viewModelScope, SharingStarted.WhileSubscribed(), true)

    // Current page index
    private val _currentPage = MutableStateFlow(0)
    val currentPage: StateFlow<Int> = _currentPage

    // Edit mode
    private val _isEditMode = MutableStateFlow(false)
    val isEditMode: StateFlow<Boolean> = _isEditMode

    fun setPage(index: Int) { _currentPage.value = index }
    fun toggleEditMode() { _isEditMode.value = !_isEditMode.value }
    fun setEditMode(enabled: Boolean) { _isEditMode.value = enabled }

    fun moveItem(id: Long, newScreen: Int, newX: Int, newY: Int) {
        viewModelScope.launch {
            favoriteDao.getById(id)?.let {
                favoriteDao.update(it.copy(screen = newScreen, cellX = newX, cellY = newY))
            }
        }
    }

    fun deleteItem(id: Long) {
        viewModelScope.launch { favoriteDao.deleteById(id) }
    }
}
