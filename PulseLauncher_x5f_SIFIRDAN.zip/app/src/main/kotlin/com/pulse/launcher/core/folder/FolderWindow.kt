package com.pulse.launcher.core.folder

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pulse.launcher.data.database.entity.FavoriteEntity

@Composable
fun FolderWindow(
    title: String,
    items: List<FavoriteEntity>,
    onDismiss: () -> Unit,
    onItemClick: (FavoriteEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(24.dp),
        shape = MaterialTheme.shapes.extraLarge
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))
            LazyVerticalGrid(columns = GridCells.Fixed(4)) {
                items(items) { item ->
                    TextButton(onClick = { onItemClick(item) }) {
                        Text(item.title ?: "App")
                    }
                }
            }
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    }
}
