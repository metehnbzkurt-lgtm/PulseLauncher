package com.pulse.launcher.features.backup

import android.content.Context
import android.net.Uri
import com.pulse.launcher.data.database.PulseDatabase
import com.pulse.launcher.data.database.entity.FavoriteEntity
import com.pulse.launcher.preferences.PreferenceManager
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BackupManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val db: PulseDatabase,
    private val prefs: PreferenceManager
) {
    suspend fun exportToUri(uri: Uri) = withContext(Dispatchers.IO) {
        val favorites = db.favoriteDao().getByContainer(-100) + db.favoriteDao().getByContainer(-101)
        val json = JSONObject().apply {
            put("version", 1)
            put("favorites", JSONArray().apply {
                favorites.forEach { fav ->
                    put(JSONObject().apply {
                        put("title", fav.title)
                        put("intent", fav.intent)
                        put("container", fav.container)
                        put("screen", fav.screen)
                        put("cellX", fav.cellX)
                        put("cellY", fav.cellY)
                    })
                }
            })
        }
        context.contentResolver.openOutputStream(uri)?.use { out ->
            out.write(json.toString(2).toByteArray())
        }
    }

    suspend fun importFromUri(uri: Uri) = withContext(Dispatchers.IO) {
        val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: return@withContext
        val json = JSONObject(text)
        val arr = json.getJSONArray("favorites")
        val entities = mutableListOf<FavoriteEntity>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            entities.add(
                FavoriteEntity(
                    itemType = 0,
                    container = obj.getLong("container"),
                    screen = obj.getInt("screen"),
                    cellX = obj.getInt("cellX"),
                    cellY = obj.getInt("cellY"),
                    title = obj.optString("title"),
                    intent = obj.optString("intent"),
                    iconPackage = null,
                    iconResource = null
                )
            )
        }
        db.favoriteDao().clearAll()
        db.favoriteDao().insertAll(entities)
    }
}
