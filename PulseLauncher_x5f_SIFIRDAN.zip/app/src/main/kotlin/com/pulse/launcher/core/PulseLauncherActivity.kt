package com.pulse.launcher.core

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.pulse.launcher.core.drawer.AppDrawerController
import com.pulse.launcher.core.gesture.GestureController
import com.pulse.launcher.core.gesture.pulseGestures
import com.pulse.launcher.core.workspace.Workspace
import com.pulse.launcher.core.workspace.WorkspaceViewModel
import com.pulse.launcher.navigation.Routes
import com.pulse.launcher.preferences.ui.screens.SettingsHostScreen
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class PulseLauncherActivity : ComponentActivity() {

    @Inject lateinit var drawerController: AppDrawerController
    @Inject lateinit var gestureController: GestureController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MaterialTheme {
                val navController = rememberNavController()

                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    NavHost(navController = navController, startDestination = Routes.HOME) {
                        composable(Routes.HOME) {
                            LauncherHomeScreen(
                                onSettingsClick = { navController.navigate(Routes.SETTINGS) }
                            )
                        }
                        composable(Routes.SETTINGS) {
                            SettingsHostScreen(onBack = { navController.popBackStack() })
                        }
                    }
                }
            }
        }
    }

    override fun onBackPressed() {
        // Handle drawer close / folder close first
        if (drawerController.isOpen.value) {
            drawerController.close()
            return
        }
        super.onBackPressed()
    }
}

@Composable
fun LauncherHomeScreen(
    onSettingsClick: () -> Unit,
    vm: WorkspaceViewModel = hiltViewModel()
) {
    val favorites by vm.favorites.collectAsState()
    val columns by vm.columns.collectAsState()
    val rows by vm.rows.collectAsState()
    val currentPage by vm.currentPage.collectAsState()

    // Group by screen for pager
    val pages = remember(favorites) {
        favorites.groupBy { it.screen }.toSortedMap().values.toList().ifEmpty { listOf(emptyList()) }
    }

    Workspace(
        pages = pages,
        columns = columns,
        rows = rows,
        currentPage = currentPage,
        onPageChanged = { vm.setPage(it) },
        onItemClick = { /* launch intent */ },
        modifier = Modifier.fillMaxSize()
    )
}
