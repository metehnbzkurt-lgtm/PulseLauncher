package com.pulse.launcher.features.badges

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

enum class BadgeStyle { NUMBER, DOT, NONE }
enum class BadgePosition { TOP_RIGHT, TOP_LEFT, BOTTOM_RIGHT }

data class BadgeInfo(val count: Int, val packageName: String)

@Singleton
class BadgeManager @Inject constructor() {
    private val _badges = MutableStateFlow<Map<String, Int>>(emptyMap())
    val badges: StateFlow<Map<String, Int>> = _badges

    fun updateBadge(packageName: String, count: Int) {
        _badges.value = _badges.value.toMutableMap().apply {
            if (count <= 0) remove(packageName) else put(packageName, count)
        }
    }

    fun clearAll() { _badges.value = emptyMap() }
}
