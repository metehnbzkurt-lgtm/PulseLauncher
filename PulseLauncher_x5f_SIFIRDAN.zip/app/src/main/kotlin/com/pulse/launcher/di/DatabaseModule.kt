package com.pulse.launcher.di

import android.content.Context
import androidx.room.Room
import com.pulse.launcher.data.database.PulseDatabase
import com.pulse.launcher.data.database.dao.DrawerGroupDao
import com.pulse.launcher.data.database.dao.FavoriteDao
import com.pulse.launcher.data.database.dao.ShortcutDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): PulseDatabase {
        return Room.databaseBuilder(
            context,
            PulseDatabase::class.java,
            "pulse_launcher.db"
        )
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    fun provideFavoriteDao(db: PulseDatabase): FavoriteDao = db.favoriteDao()

    @Provides
    fun provideDrawerGroupDao(db: PulseDatabase): DrawerGroupDao = db.drawerGroupDao()

    @Provides
    fun provideShortcutDao(db: PulseDatabase): ShortcutDao = db.shortcutDao()
}
