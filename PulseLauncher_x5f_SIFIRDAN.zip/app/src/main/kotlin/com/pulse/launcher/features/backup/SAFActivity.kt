package com.pulse.launcher.features.backup

import android.app.Activity

class SAFActivity : Activity()
