package com.pulse.launcher.preferences

import androidx.datastore.preferences.core.*

object PreferenceKeys {
    // Desktop
    val DESKTOP_GRID_COLUMNS = intPreferencesKey("desktop_grid_columns")
    val DESKTOP_GRID_ROWS = intPreferencesKey("desktop_grid_rows")
    val DESKTOP_INFINITE_SCROLL = booleanPreferencesKey("desktop_infinite_scroll")
    val DESKTOP_SCROLL_EFFECT = stringPreferencesKey("desktop_scroll_effect")
    val DESKTOP_SHOW_LABELS = booleanPreferencesKey("desktop_show_labels")
    val DESKTOP_ICON_SIZE = intPreferencesKey("desktop_icon_size")
    val DESKTOP_LOCK = booleanPreferencesKey("desktop_lock")

    // Dock
    val DOCK_ICON_COUNT = intPreferencesKey("dock_icon_count")
    val DOCK_BACKGROUND_COLOR = intPreferencesKey("dock_background_color")
    val DOCK_BACKGROUND_BLUR = booleanPreferencesKey("dock_background_blur")
    val DOCK_AUTOCLOSE = booleanPreferencesKey("dock_autoclose")
    val DOCK_SHOW_QSB = booleanPreferencesKey("dock_show_qsb")

    // Drawer
    val DRAWER_STYLE = stringPreferencesKey("drawer_style") // VERTICAL, HORIZONTAL, CARD
    val DRAWER_GRID_COLUMNS = intPreferencesKey("drawer_grid_columns")
    val DRAWER_SHOW_PREDICTIVE = booleanPreferencesKey("drawer_show_predictive")
    val DRAWER_WORK_PROFILE = booleanPreferencesKey("drawer_work_profile")

    // Gestures
    val GESTURE_SWIPE_UP = stringPreferencesKey("gesture_swipe_up")
    val GESTURE_SWIPE_DOWN = stringPreferencesKey("gesture_swipe_down")
    val GESTURE_DOUBLE_TAP = stringPreferencesKey("gesture_double_tap")
    val GESTURE_PINCH_IN = stringPreferencesKey("gesture_pinch_in")
    val GESTURE_PINCH_OUT = stringPreferencesKey("gesture_pinch_out")
    val GESTURE_TWO_FINGER_SWIPE_UP = stringPreferencesKey("gesture_two_finger_up")
    val GESTURE_LONG_PRESS = stringPreferencesKey("gesture_long_press")
    val GESTURE_HOME_BUTTON = stringPreferencesKey("gesture_home_button")

    // Theme / Look & Feel
    val THEME_ANIMATION_SPEED = floatPreferencesKey("theme_animation_speed")
    val THEME_APP_OPEN_ANIM = stringPreferencesKey("theme_app_open_anim")
    val THEME_ICON_SHAPE = stringPreferencesKey("theme_icon_shape")
    val THEME_ICON_SHADOW = booleanPreferencesKey("theme_icon_shadow")

    // Night Mode
    val NIGHT_MODE_ENABLED = booleanPreferencesKey("night_mode_enabled")
    val NIGHT_MODE_TYPE = stringPreferencesKey("night_mode_type") // AUTO, LOCATION, CUSTOM
    val NIGHT_MODE_START = stringPreferencesKey("night_mode_start")
    val NIGHT_MODE_END = stringPreferencesKey("night_mode_end")

    // Badges
    val BADGE_STYLE = stringPreferencesKey("badge_style") // NUMBER, DOT, NONE
    val BADGE_COLOR = intPreferencesKey("badge_color")
    val BADGE_POSITION = stringPreferencesKey("badge_position")

    // Search
    val SEARCH_GLOBAL_ENABLED = booleanPreferencesKey("search_global_enabled")
    val SEARCH_SHOW_QSB = booleanPreferencesKey("search_show_qsb")

    // Misc
    val WALLPAPER_SCROLL = booleanPreferencesKey("wallpaper_scroll")
    val WIDGET_CORNER_RADIUS = intPreferencesKey("widget_corner_radius")
}
