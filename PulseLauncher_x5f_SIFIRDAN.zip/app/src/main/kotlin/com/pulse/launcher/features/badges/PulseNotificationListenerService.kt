package com.pulse.launcher.features.badges

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class PulseNotificationListenerService : NotificationListenerService() {

    @Inject lateinit var badgeManager: BadgeManager

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn?.let {
            val pkg = it.packageName
            val count = activeNotifications.count { n -> n.packageName == pkg }
            badgeManager.updateBadge(pkg, count)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        sbn?.let {
            val pkg = it.packageName
            val count = activeNotifications.count { n -> n.packageName == pkg }
            badgeManager.updateBadge(pkg, count)
        }
    }
}
