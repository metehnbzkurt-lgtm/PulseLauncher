package com.pulse.launcher.features.screenoff

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class PulseDeviceAdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
    }
}
