package com.pulse.launcher.features.search

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SearchController @Inject constructor() {
    private val _isGlobalSearchOpen = MutableStateFlow(false)
    val isGlobalSearchOpen: StateFlow<Boolean> = _isGlobalSearchOpen

    private val _isAppSearchOpen = MutableStateFlow(false)
    val isAppSearchOpen: StateFlow<Boolean> = _isAppSearchOpen

    fun openGlobalSearch() { _isGlobalSearchOpen.value = true }
    fun closeGlobalSearch() { _isGlobalSearchOpen.value = false }
    fun openAppSearch() { _isAppSearchOpen.value = true }
    fun closeAppSearch() { _isAppSearchOpen.value = false }
}
