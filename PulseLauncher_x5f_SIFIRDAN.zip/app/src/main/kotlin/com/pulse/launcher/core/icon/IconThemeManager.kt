package com.pulse.launcher.core.icon

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class IconThemeManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var themePackage: String? = null
    private var drawableMap: Map<String, String> = emptyMap()

    fun setThemePackage(pkg: String?) {
        themePackage = pkg
        // Parse appfilter.xml from theme package
        if (pkg != null) {
            try {
                val pm = context.packageManager
                val res = pm.getResourcesForApplication(pkg)
                val id = res.getIdentifier("appfilter", "xml", pkg)
                if (id != 0) {
                    // Simplified parsing – real impl would use XmlResourceParser
                    drawableMap = mapOf() // TODO parse
                }
            } catch (e: Exception) { }
        }
    }

    fun getThemedIcon(componentName: String): Drawable? {
        val pkg = themePackage ?: return null
        val iconName = drawableMap[componentName] ?: return null
        return try {
            val res = context.packageManager.getResourcesForApplication(pkg)
            val id = res.getIdentifier(iconName, "drawable", pkg)
            if (id != 0) res.getDrawable(id, null) else null
        } catch (e: Exception) { null }
    }
}
