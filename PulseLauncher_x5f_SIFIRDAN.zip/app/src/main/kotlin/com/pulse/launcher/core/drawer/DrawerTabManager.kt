package com.pulse.launcher.core.drawer

import com.pulse.launcher.core.model.AppInfo
import com.pulse.launcher.data.database.dao.DrawerGroupDao
import com.pulse.launcher.data.database.entity.DrawerGroupEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

data class DrawerTab(
    val id: Long,
    val title: String,
    val filter: (AppInfo) -> Boolean = { true }
)

@Singleton
class DrawerTabManager @Inject constructor(
    private val dao: DrawerGroupDao
) {
    val tabsFlow: Flow<List<DrawerGroupEntity>> = dao.getAllFlow()

    private val _selectedTab = MutableStateFlow<DrawerTab?>(null)
    val selectedTab: StateFlow<DrawerTab?> = _selectedTab

    fun filterByTab(apps: List<AppInfo>, tab: DrawerTab): List<AppInfo> {
        return apps.filter(tab.filter)
    }

    fun selectTab(tab: DrawerTab?) { _selectedTab.value = tab }
}
