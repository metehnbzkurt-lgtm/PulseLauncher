package com.pulse.launcher.data.repository

import com.pulse.launcher.data.database.dao.FavoriteDao
import com.pulse.launcher.data.database.entity.FavoriteEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WorkspaceRepository @Inject constructor(
    private val dao: FavoriteDao
) {
    fun getWorkspaceFlow(): Flow<List<FavoriteEntity>> = dao.getAllFlow()
    suspend fun save(item: FavoriteEntity) = dao.insert(item)
    suspend fun delete(id: Long) = dao.deleteById(id)
}
