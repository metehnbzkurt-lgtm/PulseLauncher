package com.pulse.launcher.preferences.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp

data class GridOption(val label: String, val columns: Int, val rows: Int)

@Composable
fun FancyPrefGridSelector(
    title: String,
    options: List<GridOption> = listOf(
        GridOption("4x4", 4, 4),
        GridOption("4x5", 4, 5),
        GridOption("5x5", 5, 5),
        GridOption("5x6", 5, 6),
        GridOption("6x6", 6, 6)
    ),
    selected: GridOption,
    onSelected: (GridOption) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth().padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.height(200.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(options) { opt ->
                val isSelected = opt == selected
                Box(
                    modifier = Modifier
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isSelected) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .border(
                            if (isSelected) 2.dp else 0.dp,
                            MaterialTheme.colorScheme.primary,
                            RoundedCornerShape(12.dp)
                        )
                        .clickable { onSelected(opt) },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        // Mini grid preview
                        repeat(opt.rows.coerceAtMost(4)) {
                            Row {
                                repeat(opt.columns.coerceAtMost(4)) {
                                    Box(
                                        Modifier
                                            .size(6.dp)
                                            .padding(1.dp)
                                            .background(MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(opt.label, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}
