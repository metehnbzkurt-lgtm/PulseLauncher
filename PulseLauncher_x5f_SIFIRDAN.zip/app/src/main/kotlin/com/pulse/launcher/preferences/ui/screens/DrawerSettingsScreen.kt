package com.pulse.launcher.preferences.ui.screens

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.pulse.launcher.core.drawer.DrawerStyle
import com.pulse.launcher.preferences.ui.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DrawerSettingsScreen(onBack: () -> Unit) {
    var style by remember { mutableStateOf(DrawerStyle.VERTICAL) }
    var columns by remember { mutableStateOf(5f) }
    var predictive by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("App Drawer") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }
            )
        }
    ) { padding ->
        LazyColumn(contentPadding = padding) {
            item {
                FancyPrefDropdown(
                    title = "Drawer Style",
                    subtitle = "Vertical / Horizontal / Card",
                    options = DrawerStyle.entries,
                    selected = style,
                    onSelected = { style = it }
                )
            }
            item {
                FancyPrefSeekBar(
                    title = "Columns",
                    value = columns,
                    valueRange = 3f..7f,
                    steps = 3,
                    onValueChange = { columns = it }
                )
            }
            item {
                FancyPrefSwitch(
                    title = "Predictive Apps",
                    subtitle = "Show most used apps on top",
                    checked = predictive,
                    onCheckedChange = { predictive = it }
                )
            }
            item {
                FancyPrefSwitch(
                    title = "Work Profile Tab",
                    subtitle = "Separate tab for work apps",
                    checked = false,
                    onCheckedChange = {}
                )
            }
        }
    }
}
