package com.pulse.launcher.core.drawer

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pulse.launcher.core.model.AppInfo

@Composable
fun DrawerPagedView(
    apps: List<AppInfo>,
    columns: Int = 5,
    style: DrawerStyle = DrawerStyle.VERTICAL,
    onAppClick: (AppInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    when (style) {
        DrawerStyle.VERTICAL -> {
            LazyVerticalGrid(
                columns = GridCells.Fixed(columns),
                modifier = modifier.fillMaxSize(),
                contentPadding = PaddingValues(8.dp)
            ) {
                items(apps, key = { it.componentName }) { app ->
                    AppDrawerItem(app = app, onClick = onAppClick)
                }
            }
        }
        DrawerStyle.HORIZONTAL -> {
            // Horizontal pager per page
            Text("Horizontal drawer – implement HorizontalPager")
        }
        DrawerStyle.CARD -> {
            LazyVerticalGrid(
                columns = GridCells.Fixed(1),
                modifier = modifier.fillMaxSize()
            ) {
                items(apps) { app ->
                    Card(modifier = Modifier.padding(8.dp).fillMaxWidth()) {
                        AppDrawerItem(app = app, onClick = onAppClick)
                    }
                }
            }
        }
    }
}

@Composable
fun AppDrawerItem(app: AppInfo, onClick: (AppInfo) -> Unit) {
    ListItem(
        headlineContent = { Text(app.label) },
        supportingContent = { Text(app.packageName, style = MaterialTheme.typography.bodySmall) }
    )
}
