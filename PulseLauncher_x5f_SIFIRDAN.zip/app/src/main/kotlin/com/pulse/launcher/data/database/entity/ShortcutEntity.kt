package com.pulse.launcher.data.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "shortcuts")
data class ShortcutEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val shortcutId: String,
    val title: String,
    val intent: String,
    val icon: ByteArray? = null,
    val rank: Int = 0
)
