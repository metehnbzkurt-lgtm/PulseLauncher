package com.pulse.launcher.data.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemType: Int, // 0=app, 1=folder, 2=shortcut, 3=widget
    val container: Long, // -100 desktop, -101 dock, folderId
    val screen: Int,
    val cellX: Int,
    val cellY: Int,
    val spanX: Int = 1,
    val spanY: Int = 1,
    val title: String?,
    val intent: String?, // ComponentName or URI
    val iconPackage: String?,
    val iconResource: String?,
    val customIcon: ByteArray? = null,
    val modified: Long = System.currentTimeMillis()
) {
    companion object {
        const val CONTAINER_DESKTOP = -100L
        const val CONTAINER_HOTSEAT = -101L
        const val ITEM_TYPE_APP = 0
        const val ITEM_TYPE_FOLDER = 1
        const val ITEM_TYPE_SHORTCUT = 2
        const val ITEM_TYPE_WIDGET = 3
    }
}
