package com.pulse.launcher.preferences.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import com.pulse.launcher.core.animation.ScrollEffect
import com.pulse.launcher.preferences.PreferenceKeys
import com.pulse.launcher.preferences.PreferenceManager
import com.pulse.launcher.preferences.ui.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DesktopSettingsViewModel @Inject constructor(
    private val prefs: PreferenceManager
) : ViewModel() {
    private val _columns = MutableStateFlow(5)
    val columns: StateFlow<Int> = _columns
    private val _rows = MutableStateFlow(5)
    val rows: StateFlow<Int> = _rows
    private val _infinite = MutableStateFlow(true)
    val infinite: StateFlow<Boolean> = _infinite
    private val _iconSize = MutableStateFlow(72f)
    val iconSize: StateFlow<Float> = _iconSize

    init {
        // Load from DataStore – simplified
    }

    fun setColumns(c: Int) { _columns.value = c }
    fun setRows(r: Int) { _rows.value = r }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DesktopSettingsScreen(
    onBack: () -> Unit,
    vm: DesktopSettingsViewModel = hiltViewModel()
) {
    val columns by vm.columns.collectAsState()
    val rows by vm.rows.collectAsState()
    val infinite by vm.infinite.collectAsState()
    val iconSize by vm.iconSize.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Desktop") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
                }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding)) {
            item {
                FancyPrefGridSelector(
                    title = "Grid Size",
                    selected = GridOption("${columns}x${rows}", columns, rows),
                    onSelected = {
                        vm.setColumns(it.columns)
                        vm.setRows(it.rows)
                    }
                )
            }
            item {
                FancyPrefSeekBar(
                    title = "Icon Size",
                    subtitle = "Desktop icon scale",
                    value = iconSize,
                    valueRange = 40f..120f,
                    onValueChange = {}
                )
            }
            item {
                FancyPrefSwitch(
                    title = "Infinite Scroll",
                    subtitle = "Wrap around pages",
                    checked = infinite,
                    onCheckedChange = {}
                )
            }
            item {
                FancyPrefDropdown(
                    title = "Scroll Effect",
                    options = ScrollEffect.entries,
                    selected = ScrollEffect.STANDARD,
                    onSelected = {}
                )
            }
            item {
                FancyPrefSwitch(
                    title = "Lock Desktop",
                    subtitle = "Prevent moving icons",
                    checked = false,
                    onCheckedChange = {}
                )
            }
        }
    }
}
