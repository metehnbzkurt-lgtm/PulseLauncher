package com.pulse.launcher.core.animation

import androidx.compose.ui.graphics.graphicsLayer

enum class ScrollEffect { STANDARD, CUBE, ACCORDION, ROTATE, FLIP, STACK, CAROUSEL }

object ScrollEffectEngine {
    fun getTransform(effect: ScrollEffect, pageOffset: Float): androidx.compose.ui.Modifier {
        return androidx.compose.ui.Modifier.graphicsLayer {
            when (effect) {
                ScrollEffect.STANDARD -> { alpha = 1f }
                ScrollEffect.CUBE -> {
                    rotationY = pageOffset * 90f
                    cameraDistance = 20f
                }
                ScrollEffect.ACCORDION -> {
                    scaleX = 1f - kotlin.math.abs(pageOffset) * 0.5f
                }
                ScrollEffect.ROTATE -> {
                    rotationZ = pageOffset * 20f
                    alpha = 1f - kotlin.math.abs(pageOffset) * 0.5f
                }
                ScrollEffect.FLIP -> {
                    rotationY = pageOffset * 180f
                    alpha = if (kotlin.math.abs(pageOffset) > 0.5f) 0f else 1f
                }
                ScrollEffect.STACK -> {
                    scaleX = 1f - kotlin.math.abs(pageOffset) * 0.2f
                    scaleY = 1f - kotlin.math.abs(pageOffset) * 0.2f
                    translationX = pageOffset * size.width * 0.2f
                }
                ScrollEffect.CAROUSEL -> {
                    rotationY = pageOffset * 45f
                    translationX = pageOffset * size.width * 0.3f
                }
            }
        }
    }
}
