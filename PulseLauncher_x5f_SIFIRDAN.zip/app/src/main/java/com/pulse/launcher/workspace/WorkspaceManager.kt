package com.pulse.launcher.workspace
import com.pulse.launcher.data.local.entity.WorkspaceItem
import com.pulse.launcher.data.repository.LauncherRepository
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class WorkspaceManager @Inject constructor(private val repo: LauncherRepository) {
    val items = repo.workspace()
    suspend fun pinApp(packageName: String, label: String, x: Int, y: Int) {
        repo.add(WorkspaceItem(packageName = packageName, label = label, cellX = x, cellY = y))
    }
}
