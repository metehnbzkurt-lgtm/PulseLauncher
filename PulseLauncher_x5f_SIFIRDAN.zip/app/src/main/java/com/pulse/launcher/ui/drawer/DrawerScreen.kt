package com.pulse.launcher.ui.drawer
import androidx.compose.foundation.layout.*
import androidx.compose.lazy.LazyColumn
import androidx.compose.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
data class AppEntry(val packageName: String, val label: String)
@Composable
fun DrawerScreen(apps: List<AppEntry>, onAppClick: (AppEntry)->Unit) {
    Column(Modifier.fillMaxSize()) {
        TextField(value = "", onValueChange = {}, placeholder = { Text("Search apps...") }, modifier = Modifier.fillMaxWidth().padding(12.dp))
        LazyColumn {
            items(apps) { app ->
                ListItem(headlineContent = { Text(app.label) }, supportingContent = { Text(app.packageName) }, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}
