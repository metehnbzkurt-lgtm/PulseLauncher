package com.pulse.launcher.ui
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.*
import com.pulse.launcher.data.local.entity.WorkspaceItem
import com.pulse.launcher.ui.desktop.DesktopScreen
import com.pulse.launcher.ui.drawer.AppEntry
import com.pulse.launcher.ui.drawer.DrawerScreen
import com.pulse.launcher.ui.settings.SettingsScreen
import com.pulse.launcher.ui.theme.PulseTheme
import com.pulse.launcher.ui.dock.DockView
import dagger.hilt.android.AndroidEntryPoint
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PulseTheme {
                val nav = rememberNavController()
                var items by remember { mutableStateOf(listOf(WorkspaceItem(packageName="com.example", label="Demo App", cellX=0, cellY=0))) }
                Scaffold(bottomBar = { DockView() }) { pad ->
                    Box(Modifier.padding(pad)) {
                        NavHost(navController = nav, startDestination = "desktop") {
                            composable("desktop") { DesktopScreen(items) { nav.navigate("drawer") } }
                            composable("drawer") { DrawerScreen(listOf(AppEntry("com.android.chrome","Chrome"), AppEntry("com.google.android.gm","Gmail"))) {} }
                            composable("settings") { SettingsScreen() }
                        }
                    }
                }
            }
        }
    }
}
