package com.pulse.launcher.data.local.entity
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "workspace")
data class WorkspaceItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val label: String,
    val page: Int = 0,
    val cellX: Int = 0,
    val cellY: Int = 0,
    val isFolder: Boolean = false
)
