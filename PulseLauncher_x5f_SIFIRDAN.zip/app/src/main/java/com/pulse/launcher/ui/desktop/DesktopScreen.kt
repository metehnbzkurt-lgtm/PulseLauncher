package com.pulse.launcher.ui.desktop
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pulse.launcher.data.local.entity.WorkspaceItem
@Composable
fun DesktopScreen(items: List<WorkspaceItem>, onOpenDrawer: ()->Unit) {
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Desktop - Pulse", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(4), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(items) { item ->
                Card { Box(Modifier.padding(12.dp)) { Text(item.label) } }
            }
        }
        Spacer(Modifier.weight(1f))
        Button(onClick = onOpenDrawer) { Text("Open Drawer") }
    }
}
