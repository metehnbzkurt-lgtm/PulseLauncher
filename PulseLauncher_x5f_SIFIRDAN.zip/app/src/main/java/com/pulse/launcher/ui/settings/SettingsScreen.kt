package com.pulse.launcher.ui.settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.pulse.launcher.ui.components.FancySwitchPref
import com.pulse.launcher.ui.components.FancySliderPref
@Composable
fun SettingsScreen() {
    var night by remember { mutableStateOf(false) }
    var grid by remember { mutableStateOf(4f) }
    LazyColumn {
        item { FancySwitchPref("Night Mode", night) { night = it } }
        item { FancySliderPref("Grid Size", grid) { grid = it } }
        item { ListItem(headlineContent = { Text("Gestures") }) }
        item { ListItem(headlineContent = { Text("Look & Feel") }) }
        item { ListItem(headlineContent = { Text("Backup / Restore") }) }
        item { ListItem(headlineContent = { Text("Labs") }) }
    }
}
