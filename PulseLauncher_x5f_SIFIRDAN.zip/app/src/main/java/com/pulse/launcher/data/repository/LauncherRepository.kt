package com.pulse.launcher.data.repository
import com.pulse.launcher.data.local.dao.WorkspaceDao
import com.pulse.launcher.data.local.entity.WorkspaceItem
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton
@Singleton
class LauncherRepository @Inject constructor(private val dao: WorkspaceDao) {
    fun workspace(): Flow<List<WorkspaceItem>> = dao.observeAll()
    suspend fun add(item: WorkspaceItem) = dao.insert(item)
    suspend fun remove(item: WorkspaceItem) = dao.delete(item)
}
