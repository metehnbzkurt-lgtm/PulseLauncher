package com.pulse.launcher.gestures
enum class Gesture { DOUBLE_TAP, SWIPE_UP, SWIPE_DOWN }
enum class GestureAction { SCREEN_OFF, OPEN_DRAWER, SEARCH, NONE }
class GestureHandler {
    fun handle(gesture: Gesture): GestureAction = when(gesture) {
        Gesture.DOUBLE_TAP -> GestureAction.SCREEN_OFF
        Gesture.SWIPE_UP -> GestureAction.OPEN_DRAWER
        Gesture.SWIPE_DOWN -> GestureAction.SEARCH
    }
}
