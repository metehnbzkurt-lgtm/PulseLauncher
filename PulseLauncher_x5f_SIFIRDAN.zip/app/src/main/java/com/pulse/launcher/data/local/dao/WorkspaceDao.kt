package com.pulse.launcher.data.local.dao
import androidx.room.*
import com.pulse.launcher.data.local.entity.WorkspaceItem
import kotlinx.coroutines.flow.Flow
@Dao
interface WorkspaceDao {
    @Query("SELECT * FROM workspace ORDER BY page, cellY, cellX")
    fun observeAll(): Flow<List<WorkspaceItem>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: WorkspaceItem)
    @Delete
    suspend fun delete(item: WorkspaceItem)
    @Query("DELETE FROM workspace")
    suspend fun clear()
}
