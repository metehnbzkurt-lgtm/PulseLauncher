package com.pulse.launcher.di
import android.content.Context
import androidx.room.Room
import com.pulse.launcher.data.local.dao.WorkspaceDao
import com.pulse.launcher.data.local.db.PulseDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides @Singleton
    fun provideDb(@ApplicationContext ctx: Context): PulseDatabase =
        Room.databaseBuilder(ctx, PulseDatabase::class.java, "pulse.db").fallbackToDestructiveMigration().build()
    @Provides
    fun provideDao(db: PulseDatabase): WorkspaceDao = db.workspaceDao()
}
