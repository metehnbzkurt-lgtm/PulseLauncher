package com.pulse.launcher.data.local.db
import androidx.room.Database
import androidx.room.RoomDatabase
import com.pulse.launcher.data.local.dao.WorkspaceDao
import com.pulse.launcher.data.local.entity.WorkspaceItem
@Database(entities = [WorkspaceItem::class], version = 1, exportSchema = false)
abstract class PulseDatabase : RoomDatabase() {
    abstract fun workspaceDao(): WorkspaceDao
}
