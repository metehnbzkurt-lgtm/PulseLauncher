package com.pulse.launcher.ui.components
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
@Composable
fun FancySwitchPref(title: String, checked: Boolean, onChecked: (Boolean)->Unit) {
    Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title)
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}
@Composable
fun FancySliderPref(title: String, value: Float, onValue: (Float)->Unit) {
    Column(Modifier.fillMaxWidth().padding(16.dp)) {
        Text(title)
        Slider(value = value, onValueChange = onValue)
    }
}
