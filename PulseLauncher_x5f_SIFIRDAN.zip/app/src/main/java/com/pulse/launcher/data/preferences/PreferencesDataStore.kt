package com.pulse.launcher.data.preferences
import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton
private val Context.dataStore by preferencesDataStore("pulse_prefs")
@Singleton
class PreferencesDataStore @Inject constructor(@ApplicationContext private val context: Context) {
    companion object {
        val GRID_SIZE = intPreferencesKey("grid_size")
        val DOCK_SIZE = intPreferencesKey("dock_size")
        val NIGHT_MODE = booleanPreferencesKey("night_mode")
        val GESTURE_DOUBLE_TAP = stringPreferencesKey("gesture_double_tap")
    }
    val prefs = context.dataStore.data.map { it }
    suspend fun setGrid(size: Int) { context.dataStore.edit { it[GRID_SIZE] = size } }
    suspend fun setNightMode(enabled: Boolean) { context.dataStore.edit { it[NIGHT_MODE] = enabled } }
}
