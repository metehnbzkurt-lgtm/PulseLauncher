package com.pulse.launcher.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
private val DarkColorScheme = darkColorScheme(primary = Color(0xFF0A84FF), secondary = Color(0xFF5E5CE6))
private val LightColorScheme = lightColorScheme(primary = Color(0xFF007AFF), secondary = Color(0xFF5856D6))
@Composable
fun PulseTheme(darkTheme: Boolean = false, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme, content = content)
}
