package com.pulse.launcher.icons
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
class AdaptiveIconProvider {
    fun getIcon(info: ApplicationInfo): Drawable? = null
}
