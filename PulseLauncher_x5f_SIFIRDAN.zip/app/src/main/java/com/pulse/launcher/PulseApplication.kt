package com.pulse.launcher
import android.app.Application
import dagger.hilt.android.HiltAndroidApp
@HiltAndroidApp
class PulseApplication : Application()
