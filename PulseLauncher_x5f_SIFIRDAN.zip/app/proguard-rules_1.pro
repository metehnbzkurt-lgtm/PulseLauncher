# Keep Hilt etc
-keep class dagger.hilt.** { *; }
