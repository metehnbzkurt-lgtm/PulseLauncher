# PulseLauncher

Modern Android Launcher
- Package: `com.pulse.launcher`
- Min SDK 26, Target 35
- Kotlin + Jetpack Compose + Clean Architecture + MVVM + Single Activity
- Hilt, Room, DataStore, Coil, Material3, Navigation Compose
- Features: Desktop, Dock, Drawer, Folders, Gestures, Night Mode, Search, Adaptive Icons, Settings, Backup/Restore, Labs

## Build
./gradlew assembleDebug
APK at app/build/outputs/apk/debug/

## GitHub Actions
Push to main -> Android CI builds APK automatically.
