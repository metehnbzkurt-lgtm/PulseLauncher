# PulseLauncher – Modern Jetpack Compose Launcher

- Package: `com.pulse.launcher`
- Min SDK 26, Target SDK 35
- Single Activity, MVVM + Clean Architecture, Hilt, Room, DataStore, Coil, Material3
- Nova-level features: Workspace, Dock, Drawer, Folders, Gestures, Badges, Search, Adaptive Icons, Night Mode, Widgets, Backup/Restore, ScreenOff.

## Build
1. Android Studio Ladybug+
2. Open folder `PulseLauncher`
3. Sync Gradle (libs.versions.toml)
4. Run on device – set as Default Launcher.

## Structure
- `core/` – Workspace, CellLayout, Hotseat, drawer, folder, gesture, icon, animation, model
- `features/` – nightmode, badges (NotificationListenerService), search, theme, wallpaper, widget, integration, backup, screenoff
- `preferences/` – DataStore wrapper + FancyPref Compose UI + Settings screens
- `data/` – Room entities/DAO/database + repositories
- `di/` – Hilt modules
- `navigation/` – NavHost

## Key Decisions
- DataStore for all prefs, Flow-based
- Room for favorites (desktop, dock, folder) + drawer groups + shortcuts
- AdaptiveIconRenderer: shape clipping (circle, squircle, rounded square, teardrop, hexagon), shadow, normalization
- GestureController: executes GestureAction enum mapped from prefs
- ScrollEffectEngine: Cube, Accordion, Rotate, Flip, Stack, Carousel
- Edge-to-edge, 120fps ready, Material3 dynamic color.

## TODO for production
- Real WallpaperManager parallax via Window.setWallpaperOffsets
- WidgetHostView embedding via AndroidView
- Icon pack parser (appfilter.xml)
- Sesame service binding
- Backup encryption
