# GitHub'a Yükleme ve Derleme Rehberi

## Yöntem 1: Zip'i Direkt GitHub Web'den Yükle (En Kolay)

1. github.com -> New Repository -> `PulseLauncher` adında public repo oluştur (README ekleme)
2. Repo sayfasında `Add file` -> `Upload files`
3. Bu zip'i bilgisayarına indir, içini çıkar (PulseLauncher klasörü)
4. Klasörün İÇİNDEKİ tüm dosya ve klasörleri seçip sürükle-bırak ile GitHub upload alanına at
   - .github klasörü gizli olduğu için görünmeyebilir, mutlaka dahil et
5. Commit mesajı yaz: "Initial commit - PulseLauncher" -> Commit changes
6. Üstte `Actions` sekmesine git -> `Android CI` workflow'u otomatik başlayacak
7. 3-5 dk sonra yeşil tik olunca `Artifacts` kısmından `PulseLauncher-debug-apk` olarak APK'yı indir

## Yöntem 2: Git ile Push (Önerilen)

Terminal / Git Bash:

```bash
# zip'i çıkar
unzip PulseLauncher.zip -d PulseLauncher
cd PulseLauncher

git init
git add .
git commit -m "feat: initial PulseLauncher - Nova level Compose launcher"

# GitHub'da oluşturduğun boş repo'nun URL'si
git remote add origin https://github.com/KULLANICI_ADIN/PulseLauncher.git
git branch -M main
git push -u origin main
```

Push sonrası Actions otomatik APK derleyecek.

## Yöntem 3: Release olarak Zip Yükle

1. Repo -> Releases -> Draft a new release
2. Tag: v1.0.0 yaz -> Release title: PulseLauncher v1.0.0
3. Bu `PulseLauncher.zip` dosyasını Binary olarak ekle
4. Publish release

## Derleme Sorunları

- `SDK location not found` -> `local.properties` dosyası GitHub'a push edilmez, Actions için gerek yok, local'de `sdk.dir=/Users/.../Android/Sdk` olmalı
- Gradle Wrapper jar eksik derse: local'de bir kez `gradle wrapper` çalıştır ve oluşan `gradle/wrapper/gradle-wrapper.jar` dosyasını commit et
- Min SDK 26, Target 35 -> Android Studio Ladybug+ gerekir

## APK'yı Telefona Kur

- GitHub Actions artifact'tan indirdiğin `app-debug.apk` -> telefona at
- Ayarlar -> Varsayılan Uygulamalar -> Ana Sayfa Uygulaması -> PulseLauncher seç
